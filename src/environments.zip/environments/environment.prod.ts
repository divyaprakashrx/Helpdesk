export const environment = {
  production: true,
  config: {
    apiKey: "AIzaSyAMZIuhLZ4dRqEuq7Mm5AVg4B1JZvQtnd4",
    authDomain: "ecovid-19-helpdesk.firebaseapp.com",
    databaseURL: "https://ecovid-19-helpdesk.firebaseio.com",
    projectId: "ecovid-19-helpdesk",
    storageBucket: "ecovid-19-helpdesk.appspot.com",
    messagingSenderId: "5097081021",
    appId: "1:5097081021:web:d551b39d4ecd70135f4fd4",
    measurementId: "G-E98R5761EP"
  }
};
