// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  config: {
    apiKey: "AIzaSyAMZIuhLZ4dRqEuq7Mm5AVg4B1JZvQtnd4",
    authDomain: "ecovid-19-helpdesk.firebaseapp.com",
    databaseURL: "https://ecovid-19-helpdesk.firebaseio.com",
    projectId: "ecovid-19-helpdesk",
    storageBucket: "ecovid-19-helpdesk.appspot.com",
    messagingSenderId: "5097081021",
    appId: "1:5097081021:web:d551b39d4ecd70135f4fd4",
    measurementId: "G-E98R5761EP"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
